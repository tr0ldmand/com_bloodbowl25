<?php
// No direct access to this file
defined('_JEXEC') or die;
 
?>
 
<p>
You must be logged in to use this resource.
</p>
