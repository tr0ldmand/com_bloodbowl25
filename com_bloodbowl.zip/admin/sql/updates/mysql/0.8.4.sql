-- Comment
ALTER TABLE  `#__bb_tourneys` ADD  `fame_rating` INT( 2 ) NOT NULL DEFAULT  '25' AFTER  `type` ;